package simplejavatexteditor;

import javax.swing.JTextArea;

public class FEdit {

    public static void clear(JTextArea textArea) {
        textArea.setText("");
    }

}